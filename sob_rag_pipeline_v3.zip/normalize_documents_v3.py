# -*- coding: utf-8 -*-
"""
normalize_documents_v3.py

INPUT PER PDF
-------------
ab_policy.md
ab_policy.table.md   OR ab_policy_table.md
ab_policy.json

OUTPUT
------
normalized_documents/
    <internal_document_id>.normalized.json
    <internal_document_id>.normalized.md

WHAT THIS SCRIPT DOES
---------------------
1. Reads all three Azure Document Intelligence outputs.
2. Extracts the INTERNAL SOB document ID from the document body.
3. Extracts HTML tables from .md.
4. Extracts Markdown tables from .table.md.
5. Extracts structured tables from .json.
6. Matches JSON table <-> HTML table <-> Markdown table.
7. Assigns canonical table IDs using the internal document ID:
       MD0000029007_A3_table_0001
8. Replaces matched HTML tables in body Markdown with:
       [TABLE: MD0000029007_A3_table_0001]
9. Saves normalized Markdown + normalized JSON.
"""

import json
import re
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from difflib import SequenceMatcher
from bs4 import BeautifulSoup


# ============================================================
# 1. CONFIGURATION
# ============================================================

INPUT_FOLDER = Path(
    r"C:\Users\mm7453\OneDrive - Point32Health\p32_workplace\adhoc\SOBs\all_extracted_files"
)

OUTPUT_FOLDER = INPUT_FOLDER.parent / "normalized_documents"
OUTPUT_FOLDER.mkdir(parents=True, exist_ok=True)

TABLE_CONTEXT_CHARS = 800
HTML_JSON_MATCH_THRESHOLD = 0.45
MARKDOWN_JSON_MATCH_THRESHOLD = 0.40


# ============================================================
# 2. BASIC UTILITIES
# ============================================================

def clean_whitespace(text: str) -> str:
    if not text:
        return ""

    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = "\n".join(line.rstrip() for line in text.splitlines())
    text = re.sub(r"\n{4,}", "\n\n\n", text)

    return text.strip()


def normalize_for_matching(text: str) -> str:
    if not text:
        return ""

    text = text.lower()
    text = BeautifulSoup(text, "html.parser").get_text(" ")
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[^a-z0-9%$.,:/\- ]+", " ", text)
    text = re.sub(r"\s+", " ", text)

    return text.strip()


# ============================================================
# 3. INTERNAL DOCUMENT ID EXTRACTION
# ============================================================

def extract_document_id(text: str) -> Optional[str]:
    """
    Extract internal ID from document content.

    Examples:
        ID: MD0000029007_A3
        ID: DN0000000547_A1
        <!-- PageHeader="ID: MD0000028999_A4 X" -->
    """

    patterns = [
        (
            r'PageHeader\s*=\s*["\']?'
            r'.*?\bID\s*:\s*'
            r'([A-Z]{2}\d+(?:_[A-Z0-9]+)?)'
        ),
        (
            r'(?im)^\s*[.\-]?\s*'
            r'ID\s*:\s*'
            r'([A-Z]{2}\d+(?:_[A-Z0-9]+)?)\b'
        ),
        (
            r'\bID\s*:\s*'
            r'([A-Z]{2}\d+(?:_[A-Z0-9]+)?)\b'
        ),
    ]

    for pattern in patterns:
        match = re.search(
            pattern,
            text,
            flags=re.IGNORECASE
        )

        if match:
            return match.group(1).upper().strip()

    return None


# ============================================================
# 4. FILE DISCOVERY
# ============================================================

def discover_documents(input_folder: Path) -> List[Dict]:
    documents = []

    for md_file in sorted(input_folder.glob("*.md")):
        lower_name = md_file.name.lower()

        # Ignore table-only markdown files.
        if lower_name.endswith(".table.md"):
            continue

        if lower_name.endswith("_table.md"):
            continue

        base_name = md_file.stem
        json_file = input_folder / f"{base_name}.json"

        table_candidates = [
            input_folder / f"{base_name}.table.md",
            input_folder / f"{base_name}_table.md",
        ]

        table_md_file = next(
            (
                candidate
                for candidate in table_candidates
                if candidate.exists()
            ),
            None
        )

        if not json_file.exists():
            print(
                f"WARNING: JSON missing for {base_name}. "
                f"Skipping document."
            )
            continue

        documents.append(
            {
                "source_base_name": base_name,
                "body_md": md_file,
                "table_md": table_md_file,
                "json": json_file,
            }
        )

    return documents


# ============================================================
# 5. HTML TABLE EXTRACTION FROM BODY MARKDOWN
# ============================================================

HTML_TABLE_PATTERN = re.compile(
    r"<table\b[^>]*>.*?</table>",
    flags=re.IGNORECASE | re.DOTALL
)


def extract_html_tables(markdown_text: str) -> List[Dict]:
    tables = []

    for index, match in enumerate(
        HTML_TABLE_PATTERN.finditer(markdown_text)
    ):
        html = match.group(0)
        soup = BeautifulSoup(html, "html.parser")

        rows = []

        for tr in soup.find_all("tr"):
            cells = []

            for cell in tr.find_all(["th", "td"]):
                value = clean_whitespace(
                    cell.get_text(" ", strip=True)
                )
                cells.append(value)

            if cells:
                rows.append(cells)

        flat_text = " ".join(
            cell
            for row in rows
            for cell in row
        )

        tables.append(
            {
                "html_index": index,
                "html": html,
                "rows": rows,
                "text": flat_text,
                "normalized_text": normalize_for_matching(flat_text),
                "start": match.start(),
                "end": match.end(),
            }
        )

    return tables


# ============================================================
# 6. MARKDOWN TABLE EXTRACTION
# ============================================================

def is_markdown_separator(line: str) -> bool:
    line = line.strip()

    if "|" not in line:
        return False

    cells = [
        cell.strip()
        for cell in line.strip("|").split("|")
    ]

    if not cells:
        return False

    return all(
        re.fullmatch(r":?-{3,}:?", cell or "")
        for cell in cells
    )


def parse_markdown_row(line: str) -> List[str]:
    return [
        cell.strip()
        for cell in line.strip().strip("|").split("|")
    ]


def extract_markdown_tables(text: str) -> List[Dict]:
    if not text:
        return []

    lines = text.splitlines()
    tables = []
    i = 0

    while i < len(lines) - 1:
        current = lines[i]
        next_line = lines[i + 1]

        if (
            "|" in current
            and is_markdown_separator(next_line)
        ):
            block_lines = [
                current,
                next_line,
            ]

            j = i + 2

            while j < len(lines):
                line = lines[j]

                if "|" not in line:
                    break

                if not line.strip():
                    break

                block_lines.append(line)
                j += 1

            markdown = "\n".join(block_lines)

            header = parse_markdown_row(
                block_lines[0]
            )

            rows = [
                parse_markdown_row(line)
                for line in block_lines[2:]
            ]

            flat_text = " ".join(
                header
                + [
                    cell
                    for row in rows
                    for cell in row
                ]
            )

            tables.append(
                {
                    "markdown_index": len(tables),
                    "markdown": markdown,
                    "header": header,
                    "rows": rows,
                    "text": flat_text,
                    "normalized_text": normalize_for_matching(flat_text),
                }
            )

            i = j
        else:
            i += 1

    return tables


# ============================================================
# 7. DOCUMENT INTELLIGENCE JSON TABLE EXTRACTION
# ============================================================

def get_analyze_result(data: Dict) -> Dict:
    return data.get("analyzeResult", data)


def get_json_table_page(table: Dict) -> Optional[int]:
    bounding_regions = (
        table.get("boundingRegions")
        or table.get("bounding_regions")
        or []
    )

    if not bounding_regions:
        return None

    region = bounding_regions[0]

    return (
        region.get("pageNumber")
        or region.get("page_number")
    )


def extract_json_tables(json_data: Dict) -> List[Dict]:
    analyze_result = get_analyze_result(json_data)
    raw_tables = analyze_result.get("tables", [])

    tables = []

    for index, table in enumerate(raw_tables):
        cells = table.get("cells", [])

        parsed_cells = []
        max_row = 0
        max_col = 0

        for cell in cells:
            row_index = cell.get(
                "rowIndex",
                cell.get("row_index", 0)
            )

            col_index = cell.get(
                "columnIndex",
                cell.get("column_index", 0)
            )

            row_span = cell.get(
                "rowSpan",
                cell.get("row_span", 1)
            )

            col_span = cell.get(
                "columnSpan",
                cell.get("column_span", 1)
            )

            content = clean_whitespace(
                cell.get("content", "")
            )

            kind = cell.get(
                "kind",
                cell.get("cellKind", "")
            )

            parsed_cells.append(
                {
                    "row": row_index,
                    "column": col_index,
                    "row_span": row_span,
                    "column_span": col_span,
                    "content": content,
                    "kind": kind,
                }
            )

            max_row = max(max_row, row_index)
            max_col = max(max_col, col_index)

        rows = [
            [""] * (max_col + 1)
            for _ in range(max_row + 1)
        ]

        for cell in parsed_cells:
            r = cell["row"]
            c = cell["column"]

            if r < len(rows) and c < len(rows[r]):
                rows[r][c] = cell["content"]

        flat_text = " ".join(
            cell
            for row in rows
            for cell in row
            if cell
        )

        spans = table.get("spans", [])

        span_offset = (
            spans[0].get("offset")
            if spans
            else None
        )

        span_length = (
            spans[0].get("length")
            if spans
            else None
        )

        tables.append(
            {
                "json_index": index,
                "page_number": get_json_table_page(table),
                "row_count": table.get(
                    "rowCount",
                    table.get("row_count", len(rows))
                ),
                "column_count": table.get(
                    "columnCount",
                    table.get(
                        "column_count",
                        max_col + 1
                    )
                ),
                "cells": parsed_cells,
                "rows": rows,
                "text": flat_text,
                "normalized_text": normalize_for_matching(flat_text),
                "span_offset": span_offset,
                "span_length": span_length,
            }
        )

    return tables


# ============================================================
# 8. TABLE MATCHING
# ============================================================

def token_jaccard(a: str, b: str) -> float:
    tokens_a = set(a.split())
    tokens_b = set(b.split())

    if not tokens_a or not tokens_b:
        return 0.0

    return (
        len(tokens_a & tokens_b)
        /
        len(tokens_a | tokens_b)
    )


def sequence_similarity(a: str, b: str) -> float:
    if not a or not b:
        return 0.0

    return SequenceMatcher(
        None,
        a,
        b
    ).ratio()


def table_similarity(a: str, b: str) -> float:
    if not a or not b:
        return 0.0

    return (
        0.70 * token_jaccard(a, b)
        +
        0.30 * sequence_similarity(a, b)
    )


def best_unused_match(
    source_text: str,
    candidates: List[Dict],
    used_indices: set,
    index_field: str,
) -> Tuple[Optional[int], float]:

    best_index = None
    best_score = -1.0

    for candidate in candidates:
        candidate_index = candidate[index_field]

        if candidate_index in used_indices:
            continue

        score = table_similarity(
            source_text,
            candidate["normalized_text"]
        )

        if score > best_score:
            best_score = score
            best_index = candidate_index

    return best_index, best_score


# ============================================================
# 9. SECTION DETECTION
# ============================================================

HEADING_PATTERN = re.compile(
    r"^(#{1,6})\s+(.+?)\s*$",
    flags=re.MULTILINE
)


def extract_headings(markdown_text: str) -> List[Dict]:
    headings = []

    for match in HEADING_PATTERN.finditer(
        markdown_text
    ):
        headings.append(
            {
                "position": match.start(),
                "level": len(match.group(1)),
                "text": clean_whitespace(
                    match.group(2)
                ),
            }
        )

    return headings


def section_at_position(
    headings: List[Dict],
    position: int
) -> Optional[str]:

    previous = [
        heading
        for heading in headings
        if heading["position"] <= position
    ]

    return (
        previous[-1]["text"]
        if previous
        else None
    )


# ============================================================
# 10. TABLE CONTEXT
# ============================================================

def context_before(
    text: str,
    position: int,
    chars: int = TABLE_CONTEXT_CHARS
) -> str:

    segment = text[
        max(0, position - chars):
        position
    ]

    segment = BeautifulSoup(
        segment,
        "html.parser"
    ).get_text("\n")

    return clean_whitespace(segment)


def context_after(
    text: str,
    position: int,
    chars: int = TABLE_CONTEXT_CHARS
) -> str:

    segment = text[
        position:
        min(len(text), position + chars)
    ]

    segment = BeautifulSoup(
        segment,
        "html.parser"
    ).get_text("\n")

    return clean_whitespace(segment)


# ============================================================
# 11. JSON TABLE -> MARKDOWN FALLBACK
# ============================================================

def escape_md_cell(value: str) -> str:
    return (
        str(value or "")
        .replace("|", "\\|")
        .replace("\n", " ")
        .strip()
    )


def rows_to_markdown(rows: List[List[str]]) -> str:
    if not rows:
        return ""

    max_cols = max(
        len(row)
        for row in rows
    )

    normalized_rows = [
        row + [""] * (max_cols - len(row))
        for row in rows
    ]

    header = normalized_rows[0]

    output = [
        "| "
        + " | ".join(
            escape_md_cell(cell)
            for cell in header
        )
        + " |",

        "| "
        + " | ".join(
            "---"
            for _ in range(max_cols)
        )
        + " |",
    ]

    for row in normalized_rows[1:]:
        output.append(
            "| "
            + " | ".join(
                escape_md_cell(cell)
                for cell in row
            )
            + " |"
        )

    return "\n".join(output)


# ============================================================
# 12. BUILD NORMALIZED TABLE OBJECTS
# ============================================================

def build_normalized_tables(
    document_id: str,
    body_md: str,
    html_tables: List[Dict],
    markdown_tables: List[Dict],
    json_tables: List[Dict],
) -> List[Dict]:

    headings = extract_headings(body_md)

    used_html = set()
    used_markdown = set()

    normalized_tables = []

    for json_table in json_tables:
        json_index = json_table["json_index"]

        table_id = (
            f"{document_id}"
            f"_table_"
            f"{json_index + 1:04d}"
        )

        # --------------------------------------------
        # JSON -> HTML
        # --------------------------------------------

        html_index, html_score = best_unused_match(
            json_table["normalized_text"],
            html_tables,
            used_html,
            "html_index"
        )

        matched_html = None

        if (
            html_index is not None
            and html_score >= HTML_JSON_MATCH_THRESHOLD
        ):
            matched_html = next(
                item
                for item in html_tables
                if item["html_index"] == html_index
            )

            used_html.add(html_index)

        elif (
            json_index < len(html_tables)
            and json_index not in used_html
        ):
            matched_html = html_tables[json_index]
            html_index = json_index

            html_score = table_similarity(
                json_table["normalized_text"],
                matched_html["normalized_text"]
            )

            used_html.add(html_index)

        # --------------------------------------------
        # JSON -> Markdown
        # --------------------------------------------

        md_index, md_score = best_unused_match(
            json_table["normalized_text"],
            markdown_tables,
            used_markdown,
            "markdown_index"
        )

        matched_markdown = None

        if (
            md_index is not None
            and md_score >= MARKDOWN_JSON_MATCH_THRESHOLD
        ):
            matched_markdown = next(
                item
                for item in markdown_tables
                if item["markdown_index"] == md_index
            )

            used_markdown.add(md_index)

        elif (
            json_index < len(markdown_tables)
            and json_index not in used_markdown
        ):
            matched_markdown = markdown_tables[json_index]
            md_index = json_index

            md_score = table_similarity(
                json_table["normalized_text"],
                matched_markdown["normalized_text"]
            )

            used_markdown.add(md_index)

        # --------------------------------------------
        # Context / section
        # --------------------------------------------

        if matched_html:
            position = matched_html["start"]

            section = section_at_position(
                headings,
                position
            )

            preceding_context = context_before(
                body_md,
                matched_html["start"]
            )

            following_context = context_after(
                body_md,
                matched_html["end"]
            )
        else:
            position = None
            section = None
            preceding_context = ""
            following_context = ""

        # --------------------------------------------
        # Preferred table representation
        # --------------------------------------------

        if matched_markdown:
            table_markdown = matched_markdown[
                "markdown"
            ]
            table_source = "table_md"
        else:
            table_markdown = rows_to_markdown(
                json_table["rows"]
            )
            table_source = (
                "document_intelligence_json"
            )

        normalized_tables.append(
            {
                "table_id": table_id,
                "table_number": json_index + 1,
                "page_number": json_table[
                    "page_number"
                ],
                "section": section,
                "row_count": json_table[
                    "row_count"
                ],
                "column_count": json_table[
                    "column_count"
                ],
                "span_offset": json_table[
                    "span_offset"
                ],
                "span_length": json_table[
                    "span_length"
                ],
                "table_markdown": table_markdown,
                "table_source": table_source,
                "json_rows": json_table["rows"],
                "preceding_context":
                    preceding_context,
                "following_context":
                    following_context,
                "html_match_score": round(
                    max(html_score, 0),
                    4
                ),
                "markdown_match_score": round(
                    max(md_score, 0),
                    4
                ),
                "html_index": (
                    matched_html["html_index"]
                    if matched_html
                    else None
                ),
                "markdown_index": (
                    matched_markdown[
                        "markdown_index"
                    ]
                    if matched_markdown
                    else None
                ),
                "body_position": position,
            }
        )

    return normalized_tables


# ============================================================
# 13. REPLACE HTML TABLES WITH PLACEHOLDERS
# ============================================================

def replace_html_with_placeholders(
    body_md: str,
    normalized_tables: List[Dict]
) -> str:

    html_tables = extract_html_tables(
        body_md
    )

    replacement_map = {
        table["html_index"]:
            table["table_id"]
        for table in normalized_tables
        if table.get("html_index") is not None
    }

    pieces = []
    last_position = 0

    for html_table in html_tables:
        start = html_table["start"]
        end = html_table["end"]
        index = html_table["html_index"]

        pieces.append(
            body_md[
                last_position:
                start
            ]
        )

        if index in replacement_map:
            pieces.append(
                f"\n\n"
                f"[TABLE: "
                f"{replacement_map[index]}]"
                f"\n\n"
            )
        else:
            # Keep unmatched table rather than deleting data.
            pieces.append(
                html_table["html"]
            )

        last_position = end

    pieces.append(
        body_md[last_position:]
    )

    return clean_whitespace(
        "".join(pieces)
    )


# ============================================================
# 14. PROCESS ONE DOCUMENT
# ============================================================

def process_document(files: Dict) -> Dict:

    source_base_name = files[
        "source_base_name"
    ]

    print("\n" + "=" * 70)
    print(
        f"Normalizing source: "
        f"{source_base_name}"
    )
    print("=" * 70)

    body_md = files["body_md"].read_text(
        encoding="utf-8",
        errors="ignore"
    )

    body_md = clean_whitespace(
        body_md
    )

    internal_document_id = extract_document_id(
        body_md
    )

    if internal_document_id:
        document_id = internal_document_id
    else:
        document_id = source_base_name

        print(
            f"WARNING: internal document ID "
            f"not found. Falling back to "
            f"filename: {source_base_name}"
        )

    if files["table_md"]:
        table_md_text = files[
            "table_md"
        ].read_text(
            encoding="utf-8",
            errors="ignore"
        )
    else:
        table_md_text = ""

    with files["json"].open(
        "r",
        encoding="utf-8"
    ) as f:
        json_data = json.load(f)

    html_tables = extract_html_tables(
        body_md
    )

    markdown_tables = extract_markdown_tables(
        table_md_text
    )

    json_tables = extract_json_tables(
        json_data
    )

    print(
        f"Internal document ID : "
        f"{document_id}"
    )
    print(
        f"HTML tables         : "
        f"{len(html_tables)}"
    )
    print(
        f"Markdown tables     : "
        f"{len(markdown_tables)}"
    )
    print(
        f"JSON tables         : "
        f"{len(json_tables)}"
    )

    normalized_tables = build_normalized_tables(
        document_id=document_id,
        body_md=body_md,
        html_tables=html_tables,
        markdown_tables=markdown_tables,
        json_tables=json_tables,
    )

    normalized_text = (
        replace_html_with_placeholders(
            body_md,
            normalized_tables
        )
    )

    normalized_document = {
        "document_id": document_id,

        "source_base_name":
            source_base_name,

        "source_files": {
            "body_markdown":
                files["body_md"].name,

            "table_markdown": (
                files["table_md"].name
                if files["table_md"]
                else None
            ),

            "document_intelligence_json":
                files["json"].name,
        },

        "body": normalized_text,

        "tables": normalized_tables,

        "statistics": {
            "html_table_count":
                len(html_tables),

            "markdown_table_count":
                len(markdown_tables),

            "json_table_count":
                len(json_tables),

            "normalized_table_count":
                len(normalized_tables),
        },
    }

    json_output = (
        OUTPUT_FOLDER
        / f"{document_id}.normalized.json"
    )

    md_output = (
        OUTPUT_FOLDER
        / f"{document_id}.normalized.md"
    )

    with json_output.open(
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            normalized_document,
            f,
            ensure_ascii=False,
            indent=2
        )

    md_output.write_text(
        normalized_text,
        encoding="utf-8"
    )

    print(
        f"Saved JSON : "
        f"{json_output.name}"
    )

    print(
        f"Saved MD   : "
        f"{md_output.name}"
    )

    return normalized_document


# ============================================================
# 15. MAIN
# ============================================================

def main():

    documents = discover_documents(
        INPUT_FOLDER
    )

    print("=" * 70)
    print(
        "AZURE DOCUMENT INTELLIGENCE "
        "SOB NORMALIZATION"
    )
    print("=" * 70)

    print(
        f"\nInput folder:\n"
        f"{INPUT_FOLDER}"
    )

    print(
        f"\nOutput folder:\n"
        f"{OUTPUT_FOLDER}"
    )

    print(
        f"\nDocuments discovered: "
        f"{len(documents)}"
    )

    successful = 0
    failed = 0

    for files in documents:
        try:
            process_document(files)
            successful += 1

        except Exception as error:
            failed += 1

            print(
                f"\nERROR processing "
                f"{files['source_base_name']}"
            )

            print(
                f"    "
                f"{type(error).__name__}: "
                f"{error}"
            )

    print("\n" + "=" * 70)
    print("NORMALIZATION COMPLETE")
    print("=" * 70)

    print(
        f"Successful : "
        f"{successful}"
    )

    print(
        f"Failed     : "
        f"{failed}"
    )


if __name__ == "__main__":
    main()
